package com.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.DAO.Groups;

public interface GroupsRepository extends CrudRepository<Groups, Integer>  
{  

}
